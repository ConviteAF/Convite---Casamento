// Servidor do convite: Node 22+, sem dependências (node:http + node:sqlite).
// Uso: ADMIN_PIN=teu-pin node server.mjs
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

const PORT = process.env.PORT || 3000;
const PIN = process.env.ADMIN_PIN;
if (!PIN || PIN.length < 6) { console.error('Defina ADMIN_PIN com pelo menos 6 caracteres.'); process.exit(1); }

const db = new DatabaseSync(process.env.DB_PATH || 'convite.db');
db.exec(`
create table if not exists guests(
  id integer primary key, code text unique not null, name text not null,
  seats integer not null default 1, phone text, opened_at text, rsvp text,
  created_at text default current_timestamp);
create table if not exists settings(k text primary key, v text);
create table if not exists log(id integer primary key, at text default current_timestamp, action text, detail text);
`);

for (const c of ['checked_in text', 'table_no text', 'note_ok integer default 0'])
  try { db.exec('alter table guests add column ' + c); } catch {} // migrações

const ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sem O/0/I/1
const newCode = () => {
  for (;;) {
    const c = [...crypto.randomBytes(8)].map(b => ALPHA[b % 32]).join('');
    if (!db.prepare('select 1 from guests where code=?').get(c)) return c;
  }
};
const log = (action, detail = '') => db.prepare('insert into log(action,detail) values(?,?)').run(action, detail);
// ---- IA (Claude) com alternativa local se falhar ----
const FACTS = `Casamento de Agnaldo e Fátima, sábado, 31 de outubro de 2026, Luanda.
Cerimónia civil e religiosa: Calemba 2, depois da Vala, Rua 1, antes da Polícia.
Copo de água: Espaço FL Cantinho, Via Expresso do Kicuxi, sentido Benfica/Zango, entre a Rua do Resort Bantu e o Casino, Rua nº 2, a 700 metros.
Contactos dos noivos: 921545634 e 925303165; WhatsApp 939855438.
Horários: cerimónia civil e religiosa às 14:00; copo de água às 20:00. Dress code: elegante, tons suaves, evitar branco.`;
const ask = async (system, user, max = 400) => {
  const key = process.env.ANTHROPIC_API_KEY; if (!key) return null;
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: AbortSignal.timeout(15000),
      headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.AI_MODEL || 'claude-sonnet-5-5', max_tokens: max, system, messages: [{ role: 'user', content: user }] }) });
    if (!r.ok) return null;
    const d = await r.json(); return d.content.filter(b => b.type === 'text').map(b => b.text).join('').trim() || null;
  } catch { return null; }
};
const faq = q => {
  q = q.toLowerCase();
  if (/hora|quando|come[cç]a/.test(q)) return 'A cerimónia civil e religiosa começa às 14:00 e o copo de água às 20:00, no dia 31 de outubro.';
  if (/cerim|igreja|calemba/.test(q)) return 'A cerimónia civil e religiosa é em Calemba 2, depois da Vala, Rua 1, antes da Polícia.';
  if (/copo|kicuxi|rece[cç]|cantinho|festa/.test(q)) return 'O copo de água é no Espaço FL Cantinho, Via Expresso do Kicuxi, sentido Benfica/Zango, entre a Rua do Resort Bantu e o Casino, Rua nº 2, a 700 metros.';
  if (/onde|local|morada|chegar/.test(q)) return 'Cerimónia: Calemba 2, depois da Vala, Rua 1, antes da Polícia. Copo de água: Espaço FL Cantinho, no Kicuxi. Veja os botões de mapa acima.';
  if (/dress|roupa|vestir|traje/.test(q)) return 'Dress code elegante, em tons suaves. Pedimos que evite o branco.';
  return 'Não tenho essa informação. Por favor contacte os noivos: 921 545 634, 925 303 165 ou WhatsApp 939 855 438.';
};
const TONES = { formal: 'Exmo(a). {n}, temos a honra de o(a) convidar para o nosso casamento a 31 de outubro de 2026. Agradecemos a confirmação da sua presença: {l}',
  familiar: 'Querido(a) {n}! Vamos casar a 31 de outubro de 2026 e queremos muito a sua presença. Confirme aqui: {l}',
  descontraido: 'Olá {n}! Vamos casar no dia 31 de outubro e a festa não é a mesma sem si. Diga-nos se vem: {l}' };

// Leitor CSV simples (aceita , ou ; e aspas)
const parseCsv = t => {
  t = t.replace(/^\ufeff/, ''); const sep = (t.split('\n')[0].match(/;/g) || []).length > (t.split('\n')[0].match(/,/g) || []).length ? ';' : ',';
  const rows = []; let r = [], c = '', q = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"') { if (t[i + 1] === '"') { c += '"'; i++; } else q = false; } else c += ch; }
    else if (ch === '"') q = true;
    else if (ch === sep) { r.push(c); c = ''; }
    else if (ch === '\n') { r.push(c); rows.push(r); r = []; c = ''; }
    else if (ch !== '\r') c += ch;
  }
  r.push(c); rows.push(r); return rows;
};
const str = (v, n) => String(v ?? '').trim().slice(0, n);

// Limite de pedidos por IP
const hits = new Map();
const limited = (ip, key, max, ms) => {
  const k = key + ip, now = Date.now(), h = (hits.get(k) || []).filter(t => now - t < ms);
  h.push(now); hits.set(k, h); return h.length > max;
};

const send = (res, code, body, type = 'application/json') => {
  res.writeHead(code, {
    'content-type': type + '; charset=utf-8',
    'x-content-type-options': 'nosniff', 'x-frame-options': 'DENY',
    'referrer-policy': 'no-referrer', 'x-robots-tag': 'noindex',
  });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
};
const readBody = req => new Promise((ok, no) => {
  let d = ''; req.on('data', c => { d += c; if (d.length > 3e6) { no(new Error('grande')); req.destroy(); } });
  req.on('end', () => { try { ok(d ? JSON.parse(d) : {}); } catch { no(new Error('json')); } });
});
const isAdmin = req => {
  const a = Buffer.from(String(req.headers['x-admin-pin'] || '')), b = Buffer.from(PIN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
const pub = g => ({ table: g.table_no, code: g.code, name: g.name, seats: g.seats, phone: g.phone, rsvp: g.rsvp ? JSON.parse(g.rsvp) : null });
const adminRow = g => ({ id: g.id, ...pub(g), openedAt: g.opened_at, checkedIn: g.checked_in, noteOk: !!g.note_ok });

const server = http.createServer(async (req, res) => {
  const ip = req.socket.remoteAddress, url = new URL(req.url, 'http://x'), p = url.pathname;
  try {
    // ---- Público ----
    if (p === '/healthz') return send(res, 200, 'ok', 'text/plain');
    if (p === '/api/config' && req.method === 'GET') {
      const r = db.prepare("select v from settings where k='photo'").get();
      return send(res, 200, { photo: r?.v || null });
    }
    if (p === '/api/wall' && req.method === 'GET') {
      const rows = db.prepare('select name, rsvp from guests where note_ok=1').all()
        .map(g => ({ name: g.name, note: JSON.parse(g.rsvp || '{}').note })).filter(x => x.note);
      return send(res, 200, rows);
    }
    if (p === '/api/chat' && req.method === 'POST') {
      if (limited(ip, 'c', 10, 60000)) return send(res, 429, { answer: 'Muitas perguntas seguidas. Tente daqui a um minuto.' });
      const q = str((await readBody(req)).question, 300); if (!q) return send(res, 400, { error: 'Pergunta vazia' });
      const a = await ask('Responde em português de Angola, em no máximo 3 frases, usando APENAS estes dados. Se a resposta não estiver neles, diz que não tens essa informação e que contactem os noivos. Nunca inventes.\n' + FACTS, q, 250);
      return send(res, 200, { answer: a || faq(q) });
    }
    let m;
    if ((m = p.match(/^\/api\/guest\/([A-Za-z0-9]{8})$/)) && req.method === 'GET') {
      if (limited(ip, 'g', 20, 60000)) return send(res, 429, { error: 'Demasiadas tentativas. Aguarde um minuto.' });
      const g = db.prepare('select * from guests where code=?').get(m[1].toUpperCase());
      if (!g) return send(res, 404, { error: 'Código não encontrado' });
      if (!g.opened_at) db.prepare('update guests set opened_at=? where id=?').run(new Date().toISOString(), g.id);
      return send(res, 200, pub(g));
    }
    if ((m = p.match(/^\/api\/rsvp\/([A-Za-z0-9]{8})$/)) && req.method === 'POST') {
      if (limited(ip, 'r', 10, 60000)) return send(res, 429, { error: 'Demasiados pedidos.' });
      const g = db.prepare('select * from guests where code=?').get(m[1].toUpperCase());
      if (!g) return send(res, 404, { error: 'Código não encontrado' });
      const b = await readBody(req);
      if (b.website) return send(res, 200, { ok: true }); // honeypot anti-spam
      const no = !!b.no, names = no ? [] : (Array.isArray(b.names) ? b.names.map(n => str(n, 80)).filter(Boolean) : []);
      if (names.length > g.seats - 1) return send(res, 400, { error: 'Excede os lugares do convite' });
      if (!no && !b.e1 && !b.e2) return send(res, 400, { error: 'Escolha pelo menos um evento' });
      const rsvp = { no, e1: !no && !!b.e1, e2: !no && !!b.e2, names, diet: str(b.diet, 200),
        tel: str(b.tel, 30), note: str(b.note, 500), at: new Date().toISOString() };
      db.prepare('update guests set rsvp=? where id=?').run(JSON.stringify(rsvp), g.id);
      log('rsvp', g.code);
      return send(res, 200, { ok: true });
    }
    // ---- Admin ----
    if (p.startsWith('/api/admin')) {
      if (limited(ip, 'a', 30, 900000)) return send(res, 429, { error: 'Bloqueado temporariamente.' });
      if (!isAdmin(req)) return send(res, 401, { error: 'PIN incorrecto' });
      hits.delete('a' + ip);
      if (p === '/api/admin/guests' && req.method === 'GET')
        return send(res, 200, db.prepare('select * from guests order by id desc').all().map(adminRow));
      if (p === '/api/admin/guests' && req.method === 'POST') {
        const b = await readBody(req), name = str(b.name, 100);
        if (!name) return send(res, 400, { error: 'Nome obrigatório' });
        const code = newCode();
        db.prepare('insert into guests(code,name,seats,phone) values(?,?,?,?)')
          .run(code, name, Math.min(20, Math.max(1, parseInt(b.seats) || 1)), str(b.phone, 30));
        log('guest+', code); return send(res, 201, { code });
      }
      if ((m = p.match(/^\/api\/admin\/guests\/(\d+)$/)) && req.method === 'DELETE') {
        db.prepare('delete from guests where id=?').run(+m[1]); log('guest-', m[1]); return send(res, 200, { ok: true });
      }
      if (p === '/api/admin/photo' && req.method === 'POST') {
        const b = await readBody(req);
        if (!/^data:image\/(jpeg|png|webp);base64,/.test(b.photo || '')) return send(res, 400, { error: 'Imagem inválida' });
        db.prepare("insert into settings(k,v) values('photo',?) on conflict(k) do update set v=excluded.v").run(b.photo);
        return send(res, 200, { ok: true });
      }
      if (p === '/api/admin/moderate' && req.method === 'POST') {
        const b = await readBody(req); db.prepare('update guests set note_ok=? where id=?').run(b.ok ? 1 : 0, +b.id); return send(res, 200, { ok: true });
      }
      if (p === '/api/admin/table' && req.method === 'POST') {
        const b = await readBody(req); db.prepare('update guests set table_no=? where id=?').run(str(b.table, 20) || null, +b.id); return send(res, 200, { ok: true });
      }
      if (p === '/api/admin/tables/auto' && req.method === 'POST') {
        const cap = Math.min(30, Math.max(2, parseInt((await readBody(req)).capacity) || 10));
        const conf = db.prepare('select * from guests').all().map(g => ({ g, n: g.rsvp && !JSON.parse(g.rsvp).no ? 1 + JSON.parse(g.rsvp).names.length : 0 }))
          .filter(x => x.n).sort((a, b) => b.n - a.n), free = [];
        for (const { g, n } of conf) { // cada convite fica junto na mesma mesa
          let i = free.findIndex(f => f >= n); if (i < 0) { free.push(Math.max(cap, n)); i = free.length - 1; }
          free[i] -= n; db.prepare('update guests set table_no=? where id=?').run(String(i + 1), g.id);
        }
        log('tables-auto', String(free.length)); return send(res, 200, { tables: free.length, assigned: conf.length });
      }
      if (p === '/api/admin/ai/message' && req.method === 'POST') {
        const b = await readBody(req), tone = TONES[b.tone] ? b.tone : 'familiar', n = str(b.name, 100) || 'convidado';
        const ai = await ask('Escreves convites curtos de casamento em português de Angola, até 50 palavras, sem inventar dados nem horários. Mantém o marcador {l} para o link.\n' + FACTS,
          `Tom: ${tone}. Convidado: ${n}. Escreve a mensagem de WhatsApp.`, 300);
        return send(res, 200, { text: (ai || TONES[tone]).replaceAll('{n}', n), ai: !!ai });
      }
      if (p === '/api/admin/ai/summary' && req.method === 'GET') {
        const all = db.prepare('select * from guests').all().map(g => ({ ...g, r: g.rsvp ? JSON.parse(g.rsvp) : null }));
        const ok = all.filter(g => g.r && !g.r.no), np = g => 1 + g.r.names.length;
        const diets = ok.map(g => g.r.diet).filter(Boolean);
        const st = { convites: all.length, confirmados: ok.length, recusados: all.filter(g => g.r?.no).length, pendentes: all.filter(g => !g.r).length,
          pessoas: ok.reduce((a, g) => a + np(g), 0), cerimonia: ok.filter(g => g.r.e1).reduce((a, g) => a + np(g), 0), copoDeAgua: ok.filter(g => g.r.e2).reduce((a, g) => a + np(g), 0),
          vegetarianos: diets.filter(d => /vegetar|vegan/i.test(d)).length, alergias: diets.filter(d => /alerg|gl[uú]ten|lact|amendoim|marisco/i.test(d)).length };
        const ai = await ask('Resume em 4 frases, em português de Angola, o estado das confirmações de um casamento. Usa só os dados fornecidos.', JSON.stringify({ st, restricoes: diets }), 300);
        return send(res, 200, { stats: st, text: ai || `${st.confirmados} convites confirmados (${st.pessoas} pessoas), ${st.recusados} recusas e ${st.pendentes} por responder. Cerimónia: ${st.cerimonia}; copo de água: ${st.copoDeAgua}. Restrições: ${st.vegetarianos} vegetarianos, ${st.alergias} com alergias.`, ai: !!ai });
      }
      if (p === '/api/admin/backup.json') {
        return send(res, 200, { version: 1, at: new Date().toISOString(),
          guests: db.prepare('select * from guests').all(), settings: db.prepare('select * from settings').all() });
      }
      if (p === '/api/admin/restore' && req.method === 'POST') {
        const b = await readBody(req);
        if (b.version !== 1 || !Array.isArray(b.guests) || b.guests.length > 5000) return send(res, 400, { error: 'Cópia inválida' });
        if (b.guests.some(g => !/^[A-HJ-NP-Z2-9]{8}$/.test(g.code) || !str(g.name, 100))) return send(res, 400, { error: 'Cópia inválida' });
        db.exec('begin');
        try {
          db.exec('delete from guests; delete from settings');
          const ins = db.prepare('insert into guests(id,code,name,seats,phone,opened_at,rsvp,created_at,checked_in,table_no,note_ok) values(?,?,?,?,?,?,?,?,?,?,?)');
          for (const g of b.guests) ins.run(g.id ?? null, g.code, str(g.name, 100), Math.min(20, Math.max(1, +g.seats || 1)), g.phone ?? null,
            g.opened_at ?? null, g.rsvp ?? null, g.created_at ?? null, g.checked_in ?? null, g.table_no ?? null, g.note_ok ? 1 : 0);
          for (const s of b.settings || []) db.prepare('insert into settings(k,v) values(?,?)').run(String(s.k), String(s.v));
          db.exec('commit');
        } catch (e) { db.exec('rollback'); return send(res, 400, { error: 'Cópia inválida' }); }
        log('restore', String(b.guests.length)); return send(res, 200, { restored: b.guests.length });
      }
      if (p === '/api/admin/import' && req.method === 'POST') {
        const b = await readBody(req);
        const rows = parseCsv(String(b.csv || '')).filter(r => r.some(c => c.trim()));
        const head = rows[0]?.map(h => h.trim().toLowerCase()) || [];
        const col = (...n) => head.findIndex(h => n.includes(h));
        const [iN, iS, iP] = [col('nome', 'name'), col('lugares', 'seats'), col('telefone', 'phone')];
        if (iN < 0) return send(res, 400, { error: 'A primeira linha precisa da coluna "nome"' });
        let n = 0;
        for (const r of rows.slice(1).slice(0, 1000)) {
          const name = str(r[iN], 100); if (!name) continue;
          db.prepare('insert into guests(code,name,seats,phone) values(?,?,?,?)')
            .run(newCode(), name, Math.min(20, Math.max(1, parseInt(r[iS]) || 1)), str(r[iP], 30)); n++;
        }
        log('import', String(n)); return send(res, 200, { imported: n });
      }
      if (p === '/api/admin/checkin' && req.method === 'POST') {
        const b = await readBody(req), code = str(b.code, 8).toUpperCase();
        const g = db.prepare('select * from guests where code=?').get(code);
        if (!g) return send(res, 404, { error: 'Código não encontrado' });
        const r = g.rsvp ? JSON.parse(g.rsvp) : null, people = r && !r.no ? 1 + r.names.length : 0;
        if (!r || r.no) return send(res, 200, { status: 'sem-rsvp', name: g.name, people: 0 });
        if (g.checked_in) return send(res, 200, { status: 'repetido', name: g.name, people, at: g.checked_in });
        db.prepare('update guests set checked_in=? where id=?').run(new Date().toISOString(), g.id);
        log('checkin', code); return send(res, 200, { status: 'ok', name: g.name, people });
      }
      if (p === '/api/admin/export.csv') {
        const q = v => '"' + String(v ?? '').replace(/"/g, '""') + '"';
        const rows = [['nome', 'codigo', 'lugares', 'telefone', 'estado', 'acompanhantes', 'restricoes', 'mensagem'],
          ...db.prepare('select * from guests').all().map(adminRow).map(x => [x.name, x.code, x.seats, x.phone,
            x.rsvp ? (x.rsvp.no ? 'recusou' : 'confirmou') : 'pendente', x.rsvp?.names.join('; '), x.rsvp?.diet, x.rsvp?.note])];
        return send(res, 200, '\ufeff' + rows.map(r => r.map(q).join(',')).join('\n'), 'text/csv');
      }
      return send(res, 404, { error: 'Não encontrado' });
    }
    // ---- Página ----
    if (req.method === 'GET') return send(res, 200, fs.readFileSync(path.join(import.meta.dirname, 'public', 'index.html'), 'utf8'), 'text/html');
    send(res, 405, { error: 'Método não permitido' });
  } catch (e) {
    send(res, 400, { error: 'Pedido inválido' });
  }
});
server.listen(PORT, () => console.log('Convite em http://localhost:' + PORT));
