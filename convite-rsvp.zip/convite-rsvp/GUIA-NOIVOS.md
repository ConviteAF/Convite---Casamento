# Guia rápido para os noivos

## 1. Entrar no painel
Abra o endereço do convite seguido de `/#admin` (ex.: `https://…onrender.com/#admin`) e escreva o PIN.

## 2. Preparar
- **Foto de capa:** escolha uma foto vertical e boa. Fica no topo do convite.
- **Convidados:** crie um a um ("Novo convite") ou importe uma lista CSV com as colunas `nome;lugares;telefone`.
  "Lugares" é o total de pessoas desse convite (convidado + acompanhantes).

## 3. Enviar os convites
- Na tabela, carregue **WhatsApp** na linha do convidado: abre a conversa com a mensagem e o link pessoal. Basta enviar.
- Quer cartões em papel? **Imprimir convites → Guardar como PDF**.
- Para um texto diferente, use o **Assistente de IA** (se estiver ativo), escolha o tom e reveja antes de enviar.

## 4. Acompanhar as respostas
- As estatísticas no topo mostram convites, confirmados, pessoas, recusados e pendentes.
- **Lembrar quem não respondeu** abre o WhatsApp com um lembrete já escrito, um a um.
- Em **Livro de honra**, aprove as mensagens que querem mostrar no convite.

## 5. Mesas
Carregue **Distribuir confirmados** (indique os lugares por mesa). Cada convite fica junto. Pode corrigir a mesa na tabela.

## 6. No dia (31 de outubro)
Quem confirma recebe um **QR Code**. Em **Check-in**, leia o QR ou escreva o código. O sistema avisa se a pessoa já entrou ou se não confirmou.

## 7. Segurança dos dados
- Carregue em **Descarregar cópia** depois de alterações importantes e todos os dias na semana do casamento. Guarde o ficheiro no telemóvel e no e-mail.
- Se os dados desaparecerem, use **Restaurar** e escolha o ficheiro.
- Não partilhe o PIN.

## Contactos no convite
921 545 634 · 925 303 165 · WhatsApp 939 855 438
