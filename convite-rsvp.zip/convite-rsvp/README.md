# Convite Agnaldo & Fátima (RSVP)
Requer Node 22.5+ (SQLite integrado, sem `npm install`).

    ADMIN_PIN=um-pin-forte node server.mjs
    # Node 22: use `node --experimental-sqlite server.mjs`
    # abrir http://localhost:3000/#admin

1. No painel (`/#admin`) carregue a foto de capa e crie os convidados.
2. Use "WhatsApp" em cada linha para enviar o link `?c=CÓDIGO`.
3. A base de dados é o ficheiro `convite.db` (faça cópias regulares).
4. Para publicar: VPS/Railway/Render com HTTPS à frente (Caddy/Nginx). Defina `ADMIN_PIN`, `PORT` e `DB_PATH` (num volume persistente).

## Importar convidados
No painel, "Importar lista (CSV)". Primeira linha: `nome;lugares;telefone` (aceita `,` ou `;`). Os códigos são gerados automaticamente.

## QR Code e check-in (dia do casamento)
- Depois de confirmar presença, o convidado vê um QR Code com o seu código.
- No painel, "Check-in": escreva o código ou use "Ler QR" (câmara; funciona em Chrome/Android com HTTPS).
- Avisa se o convidado já entrou ou se não confirmou presença.

## Livro de honra, mesas e IA
- **Livro de honra:** a mensagem do RSVP só aparece no convite depois de a aprovar no painel.
- **Mesas:** "Distribuir confirmados" preenche as mesas mantendo cada convite junto; a mesa pode ser editada na tabela.
- **IA (opcional):** defina `ANTHROPIC_API_KEY` (e, se quiser, `AI_MODEL`). Sem chave, ou se a API falhar, usa mensagens-modelo e respostas locais.
  Inclui mensagens de convite (formal/familiar/descontraído, para rever antes de enviar), chatbot que só usa os dados do evento, e resumo das respostas.

## Testes
`npm test` (Node 22.13+). Cobre: códigos únicos, RSVP (lugares, eventos, alterar resposta), anti-spam, importação CSV, check-in, livro de honra, mesas e bloqueio do admin.

## Deploy com HTTPS (VPS com Docker)
1. Aponte o domínio (registo A) para o IP do servidor.
2. Edite `Caddyfile` com o seu domínio e `cp .env.example .env` (defina `ADMIN_PIN`, e opcionalmente `ANTHROPIC_API_KEY`).
3. `docker compose up -d`. O Caddy obtém o certificado HTTPS sozinho.
4. A base de dados fica no volume `dados`.

## Cópias de segurança
`node backup.mjs pasta-de-destino` cria uma cópia consistente. Agende no servidor (ex.: `0 3 * * * cd /app && node backup.mjs /backups`) e guarde uma cópia fora do servidor.

## Antes de enviar os convites
- Faça um teste completo no telemóvel: criar convidado, abrir o link, confirmar, check-in.
- Defina um PIN forte e carregue a foto de capa.
- Adicione os contactos dos noivos no `public/index.html`. Os horários (14:00 e 20:00) já estão definidos.

## Lembretes e convites impressos
- **Lembrar quem não respondeu:** lista os convidados sem resposta; cada botão abre o WhatsApp com a mensagem pronta (envio manual, um a um).
- **Imprimir convites:** abre uma folha com um cartão por convidado (nome, QR Code, código, link e horários). Use "Guardar como PDF" na janela de impressão.
- O envio totalmente automático por WhatsApp ou e-mail exige uma conta WhatsApp Business API (ex.: Twilio) ou um serviço de e-mail (ex.: Resend). Não está incluído.

## Servidor gratuito (Render) — passo a passo
Os planos gratuitos mudam; confirme as condições em render.com/pricing antes de começar.
1. Crie uma conta gratuita no GitHub e um repositório privado; envie para lá esta pasta (`render.yaml`, `Dockerfile`, `server.mjs`, `public/`, etc.).
2. Crie uma conta no Render (render.com) e escolha **New → Blueprint**, ligando ao repositório. O `render.yaml` já configura tudo no plano `free`.
3. Quando pedir, defina `ADMIN_PIN` (forte, mínimo 6 caracteres). `ANTHROPIC_API_KEY` é opcional.
4. Aguarde o deploy. O endereço fica no formato `https://convite-agnaldo-fatima.onrender.com` (HTTPS incluído). Abra `/#admin`.

**Limitações do plano gratuito (importante):**
- O serviço **adormece** após cerca de 15 minutos sem visitas; o primeiro acesso seguinte demora a abrir. Solução: um monitor gratuito (ex.: UptimeRobot) a visitar `https://SEU-ENDERECO/healthz` de 5 em 5 minutos.
- O **disco não é permanente**: um novo deploy ou reinício pode apagar a base de dados. Solução: no painel, use **Cópia de segurança → Descarregar cópia** depois de cada lote de alterações e uma vez por dia na semana do casamento. Se os dados desaparecerem, use **Restaurar**.

**Alternativa com disco permanente e grátis:** uma VM "Always Free" da Oracle Cloud (exige cartão para verificação) com o `docker-compose.yml` deste projeto.
