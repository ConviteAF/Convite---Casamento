// Cópia de segurança consistente da base de dados: node backup.mjs [pasta]
import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
const dir = process.argv[2] || 'backups', src = process.env.DB_PATH || 'convite.db';
fs.mkdirSync(dir, { recursive: true });
const out = `${dir}/convite-${new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-')}.db`;
new DatabaseSync(src).exec(`VACUUM INTO '${out}'`);
console.log('Cópia criada:', out);
