// Testes de integração: arranca o servidor com uma base de dados temporária.
// Executar: npm test   (Node 22.13+)
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const PORT = 4100 + Math.floor(Math.random() * 500), PIN = 'pin-de-teste';
const BASE = `http://localhost:${PORT}`, dbFile = path.join(os.tmpdir(), `convite-${PORT}.db`);
let proc;
const call = async (url, method = 'GET', body, admin = true) => {
  const r = await fetch(BASE + url, { method, body: body ? JSON.stringify(body) : undefined,
    headers: admin ? { 'x-admin-pin': PIN } : {} });
  const t = await r.text(); let j; try { j = JSON.parse(t); } catch { j = t; }
  return { s: r.status, j };
};
const novo = async (name = 'Teste', seats = 3) => { // cria convite e devolve o código
  const { j } = await call('/api/admin/guests', 'POST', { name, seats }); return j.code;
};

before(async () => {
  fs.rmSync(dbFile, { force: true });
  proc = spawn('node', ['server.mjs'], { env: { ...process.env, PORT, ADMIN_PIN: PIN, DB_PATH: dbFile }, stdio: ['ignore', 'pipe', 'inherit'] });
  await new Promise(ok => proc.stdout.on('data', d => String(d).includes('Convite em') && ok()));
});
after(() => { proc.kill(); fs.rmSync(dbFile, { force: true }); });

test('códigos: 8 caracteres, sem ambíguos e únicos', async () => {
  const codes = new Set();
  for (let i = 0; i < 40; i++) codes.add(await novo('G' + i));
  assert.equal(codes.size, 40);
  for (const c of codes) assert.match(c, /^[A-HJ-NP-Z2-9]{8}$/);
});

test('RSVP: valida lugares, eventos e permite alterar', async () => {
  const c = await novo('Família Silva', 3);
  assert.equal((await call('/api/rsvp/ZZZZZZZZ', 'POST', { e1: true }, false)).s, 404);
  assert.equal((await call(`/api/rsvp/${c}`, 'POST', { e1: true, names: ['a', 'b', 'c'] }, false)).s, 400); // excede lugares
  assert.equal((await call(`/api/rsvp/${c}`, 'POST', { names: [] }, false)).s, 400);                        // sem evento
  assert.equal((await call(`/api/rsvp/${c}`, 'POST', { e1: true, e2: true, names: ['Ana'], diet: 'vegetariano' }, false)).s, 200);
  assert.equal((await call(`/api/rsvp/${c}`, 'POST', { no: true }, false)).s, 200); // alterar a resposta
  const g = (await call(`/api/guest/${c}`, 'GET', null, false)).j;
  assert.equal(g.rsvp.no, true);
  assert.deepEqual(g.rsvp.names, []);
});

test('honeypot: pedido de robô é ignorado e não guarda nada', async () => {
  const c = await novo('Robô', 2);
  assert.equal((await call(`/api/rsvp/${c}`, 'POST', { e1: true, website: 'spam.com' }, false)).s, 200);
  assert.equal((await call(`/api/guest/${c}`, 'GET', null, false)).j.rsvp, null);
});

test('importação CSV: separador ; e aspas', async () => {
  const csv = 'nome;lugares;telefone\n"Silva, Ana";2;244911111111\nPedro Costa;1;\n';
  assert.equal((await call('/api/admin/import', 'POST', { csv })).j.imported, 2);
  const sem = await call('/api/admin/import', 'POST', { csv: 'x;y\n1;2' });
  assert.equal(sem.s, 400);
  const lista = (await call('/api/admin/guests')).j;
  assert.ok(lista.some(g => g.name === 'Silva, Ana' && g.seats === 2));
});

test('check-in: sem RSVP, primeira vez, repetido e inexistente', async () => {
  const c = await novo('Check', 2);
  const ck = code => call('/api/admin/checkin', 'POST', { code });
  assert.equal((await ck(c)).j.status, 'sem-rsvp');
  await call(`/api/rsvp/${c}`, 'POST', { e1: true, names: [] }, false);
  assert.equal((await ck(c)).j.status, 'ok');
  assert.equal((await ck(c)).j.status, 'repetido');
  assert.equal((await ck('ZZZZZZZZ')).s, 404);
});

test('livro de honra: só aparece depois de aprovado', async () => {
  const c = await novo('Mural', 1);
  await call(`/api/rsvp/${c}`, 'POST', { e1: true, names: [], note: 'Parabéns!' }, false);
  const antes = (await call('/api/wall', 'GET', null, false)).j;
  assert.ok(!antes.some(m => m.note === 'Parabéns!'));
  const id = (await call('/api/admin/guests')).j.find(g => g.code === c).id;
  await call('/api/admin/moderate', 'POST', { id, ok: true });
  assert.ok((await call('/api/wall', 'GET', null, false)).j.some(m => m.note === 'Parabéns!'));
});

test('mesas: distribuição mantém cada convite junto e respeita a capacidade', async () => {
  const r = await call('/api/admin/tables/auto', 'POST', { capacity: 6 });
  assert.equal(r.s, 200);
  const g = (await call('/api/admin/guests')).j.filter(x => x.rsvp && !x.rsvp.no);
  const porMesa = {};
  for (const x of g) { assert.ok(x.table); porMesa[x.table] = (porMesa[x.table] || 0) + 1 + x.rsvp.names.length; }
  for (const n of Object.values(porMesa)) assert.ok(n <= 6);
});

test('cópia de segurança: exportar, apagar e restaurar mantém os dados', async () => {
  assert.equal((await call('/healthz', 'GET', null, false)).s, 200);
  const c = await novo('Restauro', 2);
  await call(`/api/rsvp/${c}`, 'POST', { e1: true, names: ['X'], note: 'ok' }, false);
  const cp = (await call('/api/admin/backup.json')).j;
  assert.equal(cp.version, 1);
  const antes = (await call('/api/admin/guests')).j.length;
  const id = (await call('/api/admin/guests')).j.find(g => g.code === c).id;
  await call(`/api/admin/guests/${id}`, 'DELETE');
  assert.equal((await call('/api/admin/guests')).j.length, antes - 1);
  assert.equal((await call('/api/admin/restore', 'POST', cp)).j.restored, antes);
  const g = (await call(`/api/guest/${c}`, 'GET', null, false)).j;
  assert.deepEqual(g.rsvp.names, ['X']);
  assert.equal((await call('/api/admin/restore', 'POST', { version: 1, guests: [{ code: 'x', name: 'y' }] })).s, 400);
});

test('admin: exige PIN e bloqueia tentativas em excesso', async () => {
  assert.equal((await call('/api/admin/guests', 'GET', null, false)).s, 401);
  const r = await fetch(BASE + '/api/admin/guests', { headers: { 'x-admin-pin': 'errado' } });
  assert.equal(r.status, 401);
  let ultimo;
  for (let i = 0; i < 35; i++) ultimo = (await fetch(BASE + '/api/admin/guests', { headers: { 'x-admin-pin': 'errado' } })).status;
  assert.equal(ultimo, 429);
});
